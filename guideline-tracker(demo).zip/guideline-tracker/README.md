# Guideline Tracker

Playwright automation that answers one question every time it runs:

> **Of every Jira epic assigned to me as *User Guideline*, which ones already have a correct, published BookStack page — and what is still missing?**

It turns a manual cross-check between two systems into a one-command report.

## What it checks

For each epic (one guideline page documents one epic and all its child issues):

| # | Check | Fails when |
|---|-------|-----------|
| 1 | **Page published** | The epic's *User Guideline Link* is opened like a reader would: a published page whose title starts with the epic key counts as done; a draft is **Not published yet** (skipped, not failed); a broken link or a page for another epic fails. Without a link, BookStack is searched for a page titled `<EPIC-KEY> …`. |
| 2 | **Epic link** | The epic's *User Guideline Link* field is empty, or points to a different page. Draft (`/draft/812`) and permalink (`/link/812`) URLs are matched by page id, so a link set while the page was a draft still counts. |
| 3 | **Child links** | Only checks that each child issue has a link. A child with no link is a warning (set `REQUIRE_CHILD_LINKS=true` to make it fail). QA and UI/UX tasks are ignored. |
| 4 | **Images** | Any image URL on the page is not served (e.g. files deleted from the gallery). Each image is requested over HTTP, so lazy-loaded images are not reported as broken. |

Each epic ends up as one of: **Complete**, **Not published yet**, **Needs fix** (with the reason), or **Check error** (the check itself could not run — e.g. an expired session). The terminal prints a *Needs attention* list with the reason for every failure.

Each epic is one Playwright test, so the built-in HTML report shows exactly which step failed and why.

## Output

After every run, in `reports/`:

- `screenshots/<EPIC-KEY>.png` – a screenshot of each guideline page as evidence (also attached to each test in the HTML report). `FULL_PAGE_SCREENSHOTS=true` captures the whole page.
- `dashboard.html` – progress dashboard (with a screenshot thumbnail per epic): completion %, epics without a page, link problems, broken images, a trend line over time, search and filters. Open it in any browser.
- `html/` – the full Playwright report (`npm run report`).
- `summary.csv` – for Excel or Google Sheets.
- `summary.json` and `history.json` – raw data, used to show "completed since last run" and the trend.

## Setup (once)

Requires Node.js 18+.

```bash
npm install
npx playwright install chromium
cp .env.example .env      # then fill in the URLs
```

Pick an authentication method for each site:

- **API tokens (recommended, no browser needed):** put `JIRA_EMAIL` + `JIRA_API_TOKEN` and `BOOKSTACK_TOKEN_ID` + `BOOKSTACK_TOKEN_SECRET` in `.env`.
  - Jira token: <https://id.atlassian.com/manage-profile/security/api-tokens>
  - BookStack token: your profile → *API Tokens* (needs the *Access System API* role permission).
- **Saved browser session:** leave the token fields empty and run `npm run login`. A browser opens, you log in yourself, and the session is stored in `.auth/`. Run it again whenever a session expires. (`npm run login bookstack` or `npm run login jira` refreshes just one.)

With a BookStack API token, everything — search and the image check — runs over HTTP: no browser and no session that can expire. Without a token, the saved browser session is used; `npm run check` checks the saved BookStack session first; if it has expired, a browser opens so you can log in again (tick **Remember me**), it closes by itself, and the check continues.

## Run

```bash
npm run check          # fetch Jira, check BookStack, write the reports
npm run report         # open the Playwright HTML report
npm run check:demo     # demo with anonymised sample data, no accounts needed
```

A run only fails for real problems (wrong or missing links, broken images, check errors). Guidelines that simply aren't published yet are skipped, not failed — set `STRICT=true` if you want those to fail too.

## Built to keep working

- **Nothing personal is hard-coded.** Issues are selected with `currentUser()`, so whoever runs it sees their own assignments.
- **Field IDs are looked up by name** (`User Guideline Link`, `Sprint`). If Jira admins recreate a field, the script still finds it; if they rename it, change one line in `.env`.
- **Month books are not hard-coded.** Pages are found by searching BookStack for the epic key, so new monthly books (`december-guidelines`, …) are picked up automatically.
- **Everything is configurable in `.env`:** the JQL, a sprint filter (`SPRINT_FILTER=November 2026`), whether child links are required, whether images are checked.
- **Secrets stay out of the code.** `.env` and `.auth/` are git-ignored.
- **Readable failures.** Expired sessions, wrong tokens and missing settings stop the run with a message saying what to fix.

## Run it automatically

`.github/workflows/guideline-progress.yml` runs the check every weekday at 08:00 WIB on GitHub Actions and keeps the reports as a downloadable artifact. Add the `.env` values as repository secrets to enable it. (It uses API tokens, so the image check is off there.)

On Windows you can instead schedule `npm run check` with Task Scheduler.

## Project layout

```
scripts/fetch-jira.ts         step 1: pull assigned issues from Jira, group by epic
tests/guideline-progress.spec.ts  step 2: one test per epic, four checks each
reporters/summary-reporter.ts dashboard, CSV, JSON, history
src/jira.ts                   Jira REST client (paging, field lookup by name)
src/bookstack.ts              BookStack search (API or browser), link compare, image check
src/config.ts                 settings from .env, early validation
scripts/login.ts              save a browser session for either site
mock/epics.json               anonymised demo data
```

## Tech

Playwright Test (TypeScript) · Playwright `APIRequestContext` for REST calls · Jira Cloud REST API v3 · BookStack API · custom Playwright reporter · GitHub Actions
