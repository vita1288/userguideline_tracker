import { config, paths } from '../src/config';
import { saveSession } from '../src/session';

/**
 * Saves a browser session for BookStack and/or Jira.
 *   npm run login            → both
 *   npm run login bookstack  → BookStack only
 *   npm run login jira       → Jira only
 * Not needed for a site where you use an API token instead.
 */
async function main() {
  const only = process.argv[2];
  if (!only || only === 'bookstack') {
    if (!config.bookstack.baseUrl) throw new Error('Set BOOKSTACK_URL in .env first');
    await saveSession('BookStack', `${config.bookstack.baseUrl}/login`, paths.bookstackState);
  }
  if (!only || only === 'jira') {
    if (!config.jira.baseUrl) throw new Error('Set JIRA_BASE_URL in .env first');
    await saveSession('Jira', `${config.jira.baseUrl}/jira`, paths.jiraState, true);
  }
}

main().catch((e) => {
  console.error(`✖ ${e.message}`);
  process.exit(1);
});
