import fs from 'node:fs';
import path from 'node:path';
import { assertConfig, config, paths } from '../src/config';
import { fetchEpicGroups } from '../src/jira';
import { ensureBookstackSession } from '../src/session';

/**
 * Step 1 of every run: pull the live list of epics assigned to you from Jira.
 * Playwright builds its test list before any setup hook runs, so the data has to
 * exist on disk first — the spec then creates one test per epic from this file.
 */
async function main() {
  await ensureBookstackSession();
  assertConfig();
  fs.mkdirSync(path.dirname(paths.cacheFile), { recursive: true });

  if (config.mock) {
    fs.copyFileSync(paths.mockFile, paths.cacheFile);
    console.log('MOCK mode: using mock/epics.json (no Jira/BookStack calls)');
    return;
  }

  const groups = await fetchEpicGroups();
  fs.writeFileSync(
    paths.cacheFile,
    JSON.stringify({ fetchedAt: new Date().toISOString(), jql: config.jira.jql, groups }, null, 2),
  );
  const issues = groups.reduce((n, g) => n + g.children.length + (g.epic ? 1 : 0), 0);
  console.log(`Jira: ${issues} issues in ${groups.length} epics assigned to you`);
}

main().catch((e) => {
  console.error(`\n✖ ${e.message}\n`);
  process.exit(1);
});
