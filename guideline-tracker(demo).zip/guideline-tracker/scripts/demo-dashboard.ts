import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';
import SummaryReporter from '../reporters/summary-reporter';
import type { EpicResult } from '../tests/guideline-progress.spec';

/**
 * Builds a dashboard filled with fictional data — safe to share publicly (LinkedIn,
 * portfolio). No real project, ticket, page or company name appears in it.
 *   npm run demo:dashboard  →  reports-demo/dashboard.html + dashboard.png
 */
const out = path.resolve('reports-demo');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(path.join(out, 'screenshots'), { recursive: true });

const features: Array<[string, string, 'done' | 'fix' | 'draft', string?]> = [
  ['Bulk User Import from CSV', 'Sprint 42', 'done'],
  ['Two-Factor Login for Admin Panel', 'Sprint 42', 'done'],
  ['Export Monthly Report to PDF', 'Sprint 42', 'done'],
  ['Notification Preferences Page', 'Sprint 43', 'done'],
  ['Audit Log Filters', 'Sprint 43', 'done'],
  ['Role-Based Access for Support Team', 'Sprint 43', 'fix', 'epic link points to another page'],
  ['Scheduled Email Digest', 'Sprint 43', 'done'],
  ['Customer Search Improvements', 'Sprint 44', 'done'],
  ['Invoice Template Editor', 'Sprint 44', 'done'],
  ['Password Reset Flow Redesign', 'Sprint 44', 'done'],
  ['Dark Mode for Dashboard', 'Sprint 44', 'draft'],
];

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

/** A plain, generic guideline page used for the screenshot thumbnails. */
const pageHtml = (key: string, title: string) => `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;font:15px/1.5 system-ui,sans-serif;background:#f3f4f7;color:#1f2533}
header{background:#215a8c;color:#fff;padding:14px 32px;font-weight:600}
main{max-width:980px;margin:24px auto;background:#fff;border-radius:6px;padding:28px 36px}
h1{font-size:28px;margin:0 0 6px}h4{color:#7e8c8d;font-style:italic;margin:0 0 18px}
.box{border:1px solid #e3e6ee;border-radius:6px;padding:12px 16px;margin:12px 0}
.callout{border-left:4px solid #e0a106;background:#fdf6e3}
table{width:100%;border-collapse:collapse;margin-top:10px}td{border:1px solid #dcdfe7;padding:8px;vertical-align:top}
.hdr td{background:#c2dcfb;text-align:center;font-weight:600}
.shot{height:150px;border-radius:4px;background:linear-gradient(180deg,#e9edf5 0 18%,#fff 18%);position:relative}
.shot:before{content:'';position:absolute;left:0;top:0;bottom:0;width:22%;background:#2b3445;border-radius:4px 0 0 4px}
.shot:after{content:'';position:absolute;left:28%;right:6%;top:30%;height:46%;background:repeating-linear-gradient(180deg,#eef1f6 0 14px,#fff 14px 28px)}
</style></head><body><header>Knowledge Base · Release Guides</header><main>
<h1>${key} ${title}</h1><h4>User guideline</h4>
<div class="box"><b>💡 Overview</b><br>This guide explains the new ${title.toLowerCase()} feature, who can use it and how it changes the daily workflow.</div>
<div class="box callout"><b>Important notes</b><br>- Only users with the right permission can see this menu.<br>- Changes are recorded in the activity log.</div>
<table class="hdr"><tr><td>Before</td><td>After</td></tr></table>
<table><tr><td><div class="shot"></div></td><td><div class="shot"></div></td></tr></table>
</main></body></html>`;

async function main() {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const reporter = new SummaryReporter({ outputDir: out });

  // A rising trend line for the sparkline.
  const start = Date.now() - 14 * 86_400_000;
  const history = [18, 27, 27, 36, 45, 55, 64, 73, 82].map((pct, i) => ({
    at: new Date(start + i * 1.6 * 86_400_000).toISOString(),
    pct,
    done: Math.round((pct / 100) * features.length),
    total: features.length,
  }));
  fs.writeFileSync(path.join(out, 'history.json'), JSON.stringify(history));

  for (const [i, [title, sprint, state, problem]] of features.entries()) {
    const key = `DOC-${1201 + i * 7}`;
    const url = `https://kb.example.com/books/release-guides/page/${slug(`${key} ${title}`)}`;
    let screenshot: string | null = null;
    if (state !== 'draft') {
      await page.setContent(pageHtml(key, title));
      screenshot = `screenshots/${key}.png`;
      await page.screenshot({ path: path.join(out, screenshot) });
    }
    const r: EpicResult = {
      key,
      summary: title,
      status: state === 'draft' ? 'In Progress' : 'Ready for Release',
      sprints: [sprint],
      jiraUrl: `https://example.atlassian.net/browse/${key}`,
      pageUrl: state === 'draft' ? null : url,
      pageBook: state === 'draft' ? null : 'Release Guides',
      duplicates: [],
      epicLink: state === 'fix' ? 'wrong' : 'ok',
      childrenTotal: 3,
      childrenMissing: [],
      childrenWrong: [],
      images: state === 'draft' ? null : { total: 6, broken: [] },
      issues: problem ? [problem] : [],
      warnings: [],
      screenshot,
    };
    reporter.onTestEnd({} as never, {
      status: state === 'fix' ? 'failed' : state === 'draft' ? 'skipped' : 'passed',
      attachments: [{ name: 'epic-result', contentType: 'application/json', body: Buffer.from(JSON.stringify(r)) }],
    } as never);
  }
  reporter.onEnd({} as never);

  // Ready-to-post images of the dashboard, light and dark.
  for (const scheme of ['light', 'dark'] as const) {
    const view = await browser.newPage({ viewport: { width: 1280, height: 900 }, colorScheme: scheme, deviceScaleFactor: 2 });
    await view.goto('file://' + path.join(out, 'dashboard.html'));
    await view.waitForLoadState('load');
    await view.screenshot({ path: path.join(out, `dashboard-${scheme}.png`), fullPage: true });
  }
  await browser.close();
  console.log(`Demo dashboard: ${path.join(out, 'dashboard.html')}\nImages: dashboard-light.png, dashboard-dark.png`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
