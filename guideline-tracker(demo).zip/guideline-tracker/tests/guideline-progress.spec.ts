import fs from 'node:fs';
import path from 'node:path';
import { test as base, expect, type APIRequestContext, type Browser, type Page } from '@playwright/test';
import { bookstackAuthMode, config, hasSession, paths } from '../src/config';
import {
  bookstackApi,
  checkImages,
  checkImagesViaApi,
  checkLink,
  findGuidelinePages,
  resolveLink,
  titleIsFor,
} from '../src/bookstack';
import type { EpicGroup, GuidelinePage, ImageCheck, IssueRef } from '../src/types';

type MockGroup = EpicGroup & { mock?: { pages: GuidelinePage[]; images?: ImageCheck } };

if (!fs.existsSync(paths.cacheFile)) {
  throw new Error('No Jira data yet. Run `npm run check` (it fetches Jira first), not `playwright test` directly.');
}
const data = JSON.parse(fs.readFileSync(paths.cacheFile, 'utf8')) as {
  fetchedAt: string;
  groups: MockGroup[];
};

/** Structured result per epic; the summary reporter turns these into the dashboard. */
export interface EpicResult {
  key: string;
  summary: string;
  status: string;
  sprints: string[];
  jiraUrl: string;
  pageUrl: string | null;
  pageBook: string | null;
  duplicates: string[];
  epicLink: 'ok' | 'missing' | 'wrong' | 'n/a';
  childrenTotal: number;
  childrenMissing: string[];
  childrenWrong: string[];
  images: ImageCheck | null;
  /** Things that must be fixed — these fail the test. */
  issues: string[];
  /** Worth knowing, but the guideline still counts as complete. */
  warnings: string[];
  /** Screenshot of the guideline page, relative to the reports folder. */
  screenshot: string | null;
}

/** QA and UI/UX tasks never carry a user guideline, so they are not checked. */
const needsGuidelineLink = (c: IssueRef) =>
  !/qa task|test/i.test(c.type) && !/^\s*\[(qa|ui\/?ux)\]/i.test(c.summary);

/**
 * A browser is only started when a check really needs one (session-mode search or the
 * image check). With API tokens and CHECK_IMAGES=false a run needs no browser at all.
 */
let browser: Browser | undefined;
const test = base.extend<{ openPage: () => Promise<Page> }>({
  openPage: async ({ playwright }, use, testInfo) => {
    let page: Page | undefined;
    await use(async () => {
      if (page) return page;
      // CHROMIUM_PATH lets the check use an already-installed Chromium instead of downloading one.
      browser ??= await playwright.chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
      const ctx = await browser.newContext({
        storageState: testInfo.project.use.storageState as string | undefined,
        viewport: { width: 1440, height: 900 },
      });
      page = await ctx.newPage();
      return page;
    });
    await page?.context().close();
  },
});

let api: APIRequestContext | undefined;
test.beforeAll(async () => {
  if (!config.mock && bookstackAuthMode() === 'token') api = await bookstackApi();
});
test.afterAll(async () => {
  await api?.dispose();
  await browser?.close();
  browser = undefined;
});

test.describe(`User guideline progress (Jira data from ${data.fetchedAt})`, () => {
  for (const group of data.groups) {
    test(`${group.key} ${group.summary}`, async ({ openPage }, testInfo) => {
      testInfo.annotations.push({ type: 'Jira', description: group.url });

      const r: EpicResult = {
        key: group.key,
        summary: group.summary,
        status: group.status,
        sprints: group.sprints,
        jiraUrl: group.url,
        pageUrl: null,
        pageBook: null,
        duplicates: [],
        epicLink: 'n/a',
        childrenTotal: group.children.length,
        childrenMissing: [],
        childrenWrong: [],
        images: null,
        issues: [],
        warnings: [],
        screenshot: null,
      };

      /** Screenshot of whatever page is open, saved for the dashboard and attached to the HTML report. */
      const snap = async (url?: string) => {
        if (!config.screenshots || config.mock || bookstackAuthMode() !== 'session') return;
        const p = await openPage();
        if (url && p.url().split('#')[0] !== url) await p.goto(url, { waitUntil: 'domcontentloaded' });
        await p.waitForLoadState('networkidle', { timeout: 15_000 }).catch(() => {});
        const rel = `screenshots/${group.key}.png`;
        const file = path.join(paths.reportsDir, rel);
        fs.mkdirSync(path.dirname(file), { recursive: true });
        await p.screenshot({ path: file, fullPage: config.fullPageScreenshots });
        await testInfo.attach('guideline-page', { path: file, contentType: 'image/png' });
        r.screenshot = rel;
      };

      try {
        // 1 ─ Open the "User Guideline Link" from Jira — the page you published — like a reader would.
        const link = group.epic?.guidelineLink ?? group.children.find((c) => c.guidelineLink)?.guidelineLink ?? null;
        type LinkState = 'ok' | 'draft' | 'broken' | 'other-page' | 'not-opened';
        let main = undefined as GuidelinePage | undefined;
        let linkState = 'not-opened' as LinkState;
        if (!config.mock && link && bookstackAuthMode() === 'session') {
          await test.step('User Guideline Link opens the published page', async () => {
            const res = await resolveLink(link, await openPage());
            if (res.state === 'draft') linkState = 'draft';
            else if (res.state === 'broken') {
              linkState = 'broken';
              r.issues.push(`User Guideline Link is broken (${res.reason}): ${link}`);
            } else if (!titleIsFor(res.page.name, group.key)) {
              linkState = 'other-page';
              r.issues.push(`User Guideline Link opens another page: "${res.page.name}"`);
            } else {
              linkState = 'ok';
              main = res.page;
            }
          });
        }

        // 2 ─ No usable link: look the page up by its title "<EPIC-KEY> …" instead.
        if (!main) {
          const pages = await test.step('Guideline page is published in BookStack', async () => {
            const found = config.mock
              ? group.mock?.pages ?? []
              : await findGuidelinePages(group.key, {
                  api,
                  page: bookstackAuthMode() === 'session' ? await openPage() : undefined,
                });
            if (found.length > 1) {
              r.duplicates = found.slice(1).map((p) => p.url);
              r.warnings.push(`${found.length} pages share this epic key`);
            }
            return found;
          });
          main = (link && pages.find((p) => ['ok', 'draft-url'].includes(checkLink(link, p)))) || pages[0];
          if (!main) {
            if (r.issues.length) {
              // Show what the broken link actually opened.
              if (linkState === 'broken' || linkState === 'other-page') await snap().catch(() => {});
              expect.soft(r.issues, 'guideline link problems').toEqual([]);
              return;
            }
            // Not finished yet is a status, not an error — unless STRICT=true.
            if (config.strict) expect(false, 'no published guideline page found').toBe(true);
            test.skip(true, linkState === 'draft' ? 'Still a draft' : 'Not published yet');
            return;
          }
        }
        r.pageUrl = main.url;
        r.pageBook = main.book;
        testInfo.annotations.push({ type: 'Guideline', description: main.url });

        // Is the epic's "User Guideline Link" correct?
        if (group.epic) {
          await test.step('Epic has the correct User Guideline Link', async () => {
            const epicLink = group.epic!.guidelineLink;
            if (!epicLink) {
              r.epicLink = 'missing';
              r.issues.push('epic has no User Guideline Link');
            } else if (linkState === 'ok') {
              r.epicLink = 'ok';
              if (/\/draft\/\d+/.test(epicLink)) r.warnings.push('epic link is the draft URL — consider the published page URL');
            } else if (linkState === 'broken' || linkState === 'other-page') {
              r.epicLink = 'wrong';
            } else {
              const result = checkLink(epicLink, main!);
              r.epicLink = result === 'wrong' ? 'wrong' : 'ok';
              if (result === 'wrong') r.issues.push(`epic link points to another page: ${epicLink}`);
              if (result === 'draft-url') r.warnings.push('epic link is the draft URL — consider the published page URL');
              if (result === 'unverifiable') r.warnings.push('epic link is a page-id URL that could not be verified');
            }
            expect.soft(r.epicLink, `epic link ${r.epicLink}`).toBe('ok');
          });
        }

        // 3 ─ Do the child issues have a User Guideline Link? (presence only — the epic link is the one that's verified)
        const children = group.children.filter(needsGuidelineLink);
        if (children.length) {
          await test.step('Child issues have a User Guideline Link', async () => {
            r.childrenMissing = children.filter((c) => !c.guidelineLink).map((c) => c.key);
            if (r.childrenMissing.length) {
              const msg = `child issues without link: ${r.childrenMissing.join(', ')}`;
              (config.requireChildLinks ? r.issues : r.warnings).push(msg);
            }
            if (config.requireChildLinks) expect.soft(r.childrenMissing, 'children without a link').toEqual([]);
          });
        }

        // 4 ─ Does every image on the page actually load?
        // With an API token the images are checked over HTTP, so no browser session can expire.
        const viaApi = !config.mock && !!api && !!main.id;
        const canCheck = config.mock || viaApi || hasSession(paths.bookstackState);
        if (config.checkImages && canCheck) {
          await test.step('All images on the page load', async () => {
            r.images = config.mock
              ? group.mock?.images ?? { total: 0, broken: [] }
              : viaApi
                ? await checkImagesViaApi(api!, main!.id!)
                : await checkImages(await openPage(), main!.url);
            if (r.images.broken.length) r.issues.push(`${r.images.broken.length} broken image(s)`);
            expect.soft(r.images.broken, 'broken images').toEqual([]);
          });
        }

        // 5 ─ Screenshot of the guideline page as evidence for the report.
        if (config.screenshots && !config.mock && bookstackAuthMode() === 'session') {
          await test.step('Screenshot of the guideline page', () => snap(main!.url));
        }
      } finally {
        for (const w of r.warnings) testInfo.annotations.push({ type: 'Warning', description: w });
        await testInfo.attach('epic-result', {
          body: JSON.stringify(r),
          contentType: 'application/json',
        });
      }
    });
  }
});
