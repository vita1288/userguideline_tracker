import fs from 'node:fs';
import path from 'node:path';
import type { FullResult, Reporter, TestCase, TestResult } from '@playwright/test/reporter';
import type { EpicResult } from '../tests/guideline-progress.spec';

type State = 'done' | 'no-page' | 'needs-fix' | 'error';

interface Row extends EpicResult {
  state: State;
}

const stateOf = (r: EpicResult): State =>
  !r.pageUrl ? 'no-page' : r.issues.length ? 'needs-fix' : 'done';

const esc = (s: string) =>
  s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

const csvCell = (s: string) => `"${s.replace(/"/g, '""')}"`;

/**
 * Turns the per-epic results into files you can keep or share:
 *   reports/dashboard.html  – standalone progress dashboard (open in any browser)
 *   reports/summary.csv     – for Excel / Google Sheets
 *   reports/summary.json    – raw data, also used to show the change since the last run
 *   reports/history.json    – completion % over time
 */
export default class SummaryReporter implements Reporter {
  private rows = new Map<string, Row>();
  private outDir: string;

  constructor(opts: { outputDir?: string } = {}) {
    this.outDir = path.resolve(opts.outputDir ?? 'reports');
  }

  onTestEnd(_test: TestCase, result: TestResult) {
    const att = result.attachments.find((a) => a.name === 'epic-result' && a.body);
    if (!att?.body) return;
    const r = JSON.parse(att.body.toString()) as EpicResult;
    r.warnings ??= [];
    r.screenshot ??= null;
    // A thrown error (expired session, network, …) is not a guideline problem — show it as such.
    const crashed = (result.status === 'failed' || result.status === 'timedOut') && !r.issues.length;
    if (crashed) {
      const msg = (result.error?.message ?? 'check could not run').replace(/\u001b\[[0-9;]*m/g, '').split('\n')[0];
      r.issues = [`check error: ${msg}`];
    }
    this.rows.set(r.key, { ...r, state: crashed ? 'error' : stateOf(r) }); // last attempt wins (retries)
  }

  onEnd(_result: FullResult) {
    if (!this.rows.size) return;
    fs.mkdirSync(this.outDir, { recursive: true });
    const rows = [...this.rows.values()].sort((a, b) =>
      a.key.localeCompare(b.key, undefined, { numeric: true }),
    );
    const now = new Date();
    const count = (s: State) => rows.filter((r) => r.state === s).length;
    const stats = {
      total: rows.length,
      done: count('done'),
      noPage: count('no-page'),
      needsFix: count('needs-fix'),
      errors: count('error'),
      brokenImages: rows.reduce((n, r) => n + (r.images?.broken.length ?? 0), 0),
      missingLinks: rows.reduce((n, r) => n + r.childrenMissing.length + (r.epicLink === 'missing' ? 1 : 0), 0),
      wrongLinks: rows.reduce((n, r) => n + r.childrenWrong.length + (r.epicLink === 'wrong' ? 1 : 0), 0),
    };
    const pct = Math.round((stats.done / stats.total) * 100);
    const published = Math.round(((stats.total - stats.noPage) / stats.total) * 100);

    // change since last run
    const prevFile = path.join(this.outDir, 'summary.json');
    let newlyDone: string[] = [];
    if (fs.existsSync(prevFile)) {
      try {
        const prev = JSON.parse(fs.readFileSync(prevFile, 'utf8')) as { rows: Row[] };
        const was = new Map(prev.rows.map((r) => [r.key, r.state]));
        newlyDone = rows.filter((r) => r.state === 'done' && was.get(r.key) !== 'done').map((r) => r.key);
      } catch {}
    }

    const histFile = path.join(this.outDir, 'history.json');
    const history: Array<{ at: string; pct: number; done: number; total: number }> = fs.existsSync(histFile)
      ? JSON.parse(fs.readFileSync(histFile, 'utf8'))
      : [];
    history.push({ at: now.toISOString(), pct, done: stats.done, total: stats.total });
    fs.writeFileSync(histFile, JSON.stringify(history.slice(-90), null, 2));

    fs.writeFileSync(prevFile, JSON.stringify({ generatedAt: now.toISOString(), stats, rows }, null, 2));

    const header = ['Epic', 'Summary', 'Jira status', 'Sprint', 'Result', 'Guideline page', 'Book', 'Problems', 'Warnings'];
    const csv = [header, ...rows.map((r) => [
      r.key, r.summary, r.status, r.sprints.join(' / '), r.state, r.pageUrl ?? '', r.pageBook ?? '', r.issues.join('; '), r.warnings.join('; '),
    ])].map((l) => l.map(csvCell).join(',')).join('\n');
    fs.writeFileSync(path.join(this.outDir, 'summary.csv'), csv);

    fs.writeFileSync(path.join(this.outDir, 'dashboard.html'), this.dashboard(rows, stats, pct, published, now, newlyDone, history));

    const attention = rows.filter((r) => r.state === 'needs-fix' || r.state === 'error');
    if (attention.length) {
      console.log('\nNeeds attention:');
      for (const r of attention) console.log(`  ${r.key}  ${r.issues.join(' | ')}`);
    }
    console.log(
      `\nGuideline progress: ${stats.done}/${stats.total} epics complete (${pct}%), ` +
        `${stats.noPage} not published yet, ${stats.needsFix} need fixes` +
        (stats.errors ? `, ${stats.errors} could not be checked` : '') + '.' +
        (newlyDone.length ? ` Newly complete: ${newlyDone.join(', ')}.` : '') +
        `\nDashboard: ${path.join(this.outDir, 'dashboard.html')}\n`,
    );
  }

  private dashboard(
    rows: Row[],
    s: Record<string, number>,
    pct: number,
    published: number,
    now: Date,
    newlyDone: string[],
    history: Array<{ at: string; pct: number }>,
  ) {
    const label: Record<State, string> = {
      done: 'Complete',
      'no-page': 'Not published yet',
      'needs-fix': 'Needs fix',
      error: 'Check error',
    };
    const spark = history.slice(-30);
    const sparkPts = spark
      .map((h, i) => `${spark.length === 1 ? 50 : (i / (spark.length - 1)) * 100},${30 - (h.pct / 100) * 28}`)
      .join(' ');
    const tr = rows
      .map(
        (r) => `<tr data-state="${r.state}" data-text="${esc(`${r.key} ${r.summary} ${r.sprints.join(' ')}`.toLowerCase())}">
  <td><a href="${esc(r.jiraUrl)}" target="_blank" rel="noopener">${esc(r.key)}</a></td>
  <td class="sum">${esc(r.summary)}<div class="meta">${esc(r.status)}${r.sprints.length ? ' · ' + esc(r.sprints.at(-1)!) : ''}</div></td>
  <td><span class="pill ${r.state}">${label[r.state]}</span></td>
  <td class="hide-m">${r.pageUrl ? `<a href="${esc(r.pageUrl)}" target="_blank" rel="noopener">${esc(r.pageBook || 'Open page')}</a>` : '<span class="muted">—</span>'}</td>
  <td class="hide-m shot">${r.screenshot ? `<a href="${esc(r.screenshot)}" target="_blank" rel="noopener"><img src="${esc(r.screenshot)}" alt="${esc(r.key)} guideline page" loading="lazy"></a>` : '<span class="muted">—</span>'}</td>
  <td class="probs">${r.issues.length ? r.issues.map((i) => `<div>${esc(i)}</div>`).join('') : '<span class="muted">None</span>'}${(r.warnings ?? []).map((w) => `<div class="muted">⚠ ${esc(w)}</div>`).join('')}</td>
</tr>`,
      )
      .join('\n');

    return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Guideline Progress</title>
<style>
:root{--bg:#f6f7f9;--card:#fff;--ink:#1d2330;--muted:#6b7385;--line:#e4e7ee;--accent:#2f6fde;--ok:#1f8a5b;--warn:#b7791f;--bad:#c2410c;--okbg:#e6f4ec;--warnbg:#fdf3e1;--badbg:#fdebe3}
@media (prefers-color-scheme:dark){:root{--bg:#12151c;--card:#1a1f29;--ink:#e7eaf0;--muted:#98a1b3;--line:#2a3140;--accent:#6f9ef0;--ok:#4cc38a;--warn:#e3b04b;--bad:#f0855a;--okbg:#173327;--warnbg:#3a2f17;--badbg:#3d2219}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:28px 16px 48px}
h1{font-size:22px;margin:0}.sub{color:var(--muted);margin:4px 0 22px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
.k{font-size:26px;font-weight:650}.l{color:var(--muted);font-size:12.5px}
.bar{height:8px;border-radius:99px;background:var(--line);overflow:hidden;margin-top:8px}.bar i{display:block;height:100%;background:var(--ok)}
.tools{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0 12px}
.tools input{flex:1;min-width:200px;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--ink)}
.tools button{padding:7px 12px;border:1px solid var(--line);border-radius:99px;background:var(--card);color:var(--ink);cursor:pointer}
.tools button.on{background:var(--accent);border-color:var(--accent);color:#fff}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{padding:10px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);background:var(--bg)}
tr:last-child td{border-bottom:0}a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}
.meta,.muted{color:var(--muted);font-size:12.5px}.probs div{font-size:12.5px;margin-bottom:2px}
.pill{display:inline-block;padding:2px 9px;border-radius:99px;font-size:12px;font-weight:600;white-space:nowrap}
.pill.done{background:var(--okbg);color:var(--ok)}.pill.needs-fix{background:var(--warnbg);color:var(--warn)}.pill.no-page{background:var(--line);color:var(--muted)}.pill.error{background:var(--badbg);color:var(--bad)}
.shot img{width:160px;height:100px;object-fit:cover;object-position:top;border:1px solid var(--line);border-radius:6px;display:block}
.new{margin:0 0 14px;padding:10px 14px;border-radius:8px;background:var(--okbg);color:var(--ok)}
svg{width:100%;height:34px;margin-top:6px}
@media (max-width:720px){.hide-m{display:none}th,td{padding:8px}}
</style></head><body><div class="wrap">
<h1>User Guideline Progress</h1>
<div class="sub">Jira epics assigned to me as User Guideline vs. published BookStack pages · ${esc(now.toLocaleString())}</div>
${newlyDone.length ? `<div class="new">Completed since last run: ${newlyDone.map(esc).join(', ')}</div>` : ''}
<div class="grid">
 <div class="card"><div class="k">${pct}%</div><div class="l">Fully complete (${s.done} of ${s.total} epics)</div><div class="bar"><i style="width:${pct}%"></i></div>${spark.length > 1 ? `<svg viewBox="0 0 100 32" preserveAspectRatio="none"><polyline fill="none" stroke="currentColor" stroke-width="1.5" opacity=".55" points="${sparkPts}"/></svg>` : ''}</div>
 <div class="card"><div class="k">${published}%</div><div class="l">Have a published page</div><div class="bar"><i style="width:${published}%"></i></div></div>
 <div class="card"><div class="k">${s.noPage}</div><div class="l">Not published yet</div></div>
 <div class="card"><div class="k">${s.missingLinks + s.wrongLinks}</div><div class="l">Jira link problems (${s.missingLinks} missing, ${s.wrongLinks} wrong)</div></div>
 <div class="card"><div class="k">${s.brokenImages}</div><div class="l">Broken images</div></div>
</div>
<div class="tools">
 <input id="q" placeholder="Search epic, title or sprint…" aria-label="Search">
 <button class="on" data-f="all">All ${s.total}</button><button data-f="done">Complete ${s.done}</button>
 <button data-f="needs-fix">Needs fix ${s.needsFix}</button><button data-f="no-page">Not published ${s.noPage}</button>${s.errors ? `<button data-f="error">Check error ${s.errors}</button>` : ''}
</div>
<table><thead><tr><th>Epic</th><th>Title</th><th>Result</th><th class="hide-m">Guideline</th><th class="hide-m">Screenshot</th><th>Problems</th></tr></thead>
<tbody>${tr}</tbody></table>
</div>
<script>
const q=document.getElementById('q');let f='all';
function apply(){const t=q.value.toLowerCase();document.querySelectorAll('tbody tr').forEach(r=>{r.style.display=(f==='all'||r.dataset.state===f)&&r.dataset.text.includes(t)?'':'none'})}
q.addEventListener('input',apply);
document.querySelectorAll('[data-f]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-f]').forEach(x=>x.classList.remove('on'));b.classList.add('on');f=b.dataset.f;apply()}));
</script></body></html>`;
  }
}
