import { request, type APIRequestContext } from '@playwright/test';
import { config, jiraAuthMode, paths } from './config';
import type { EpicGroup, IssueRef } from './types';

export async function jiraContext(): Promise<APIRequestContext> {
  const { baseUrl, email, apiToken } = config.jira;
  if (jiraAuthMode() === 'token') {
    const auth = Buffer.from(`${email}:${apiToken}`).toString('base64');
    return request.newContext({
      baseURL: baseUrl,
      extraHTTPHeaders: { Authorization: `Basic ${auth}`, Accept: 'application/json' },
    });
  }
  return request.newContext({
    baseURL: baseUrl,
    storageState: paths.jiraState,
    extraHTTPHeaders: { Accept: 'application/json' },
  });
}

async function getJson<T>(ctx: APIRequestContext, url: string): Promise<T> {
  const res = await ctx.get(url);
  if (!res.ok()) {
    const hint =
      res.status() === 401 || res.status() === 403
        ? ' — check JIRA_EMAIL / JIRA_API_TOKEN, or run `npm run login` again'
        : '';
    throw new Error(`Jira ${res.status()} on ${url}${hint}\n${(await res.text()).slice(0, 300)}`);
  }
  return res.json() as Promise<T>;
}

type JiraField = { id: string; name: string; schema?: { type?: string } };
const norm = (s: string) => s.toLowerCase().replace(/\s+/g, ' ').trim();

/**
 * Field IDs differ between Jira sites and can change; look them up by display name.
 * A raw ID such as "customfield_11481" is also accepted in .env.
 */
async function resolveFieldId(fields: JiraField[], name: string, preferType?: string) {
  if (/^customfield_\d+$/i.test(name.trim())) return name.trim();
  const matches = fields.filter((f) => norm(f.name) === norm(name));
  const pick = matches.find((f) => !preferType || f.schema?.type === preferType) ?? matches[0];
  return pick?.id ?? null;
}

/** Confirms the credentials work before anything else, so a bad token never looks like a missing field. */
async function whoAmI(ctx: APIRequestContext) {
  const res = await ctx.get('/rest/api/3/myself');
  if (!res.ok()) {
    throw new Error(
      `Jira rejected the login (HTTP ${res.status()}).\n` +
        '  - JIRA_EMAIL must be the exact email you use to log in to Jira\n' +
        '  - JIRA_API_TOKEN must be a classic token (not "with scopes") and not revoked\n' +
        '  - Or leave both empty and run `npm run login jira`',
    );
  }
  const me = (await res.json()) as { displayName?: string; emailAddress?: string };
  console.log(`Jira: logged in as ${me.displayName ?? 'unknown'}${me.emailAddress ? ` <${me.emailAddress}>` : ''}`);
}

interface RawIssue {
  key: string;
  fields: Record<string, any>;
}

async function searchAll(ctx: APIRequestContext, jql: string, fields: string[]) {
  const issues: RawIssue[] = [];
  let next: string | undefined;
  do {
    const params = new URLSearchParams({ jql, maxResults: '100', fields: fields.join(',') });
    if (next) params.set('nextPageToken', next);
    const page = await getJson<{ issues: RawIssue[]; nextPageToken?: string }>(
      ctx,
      `/rest/api/3/search/jql?${params}`,
    );
    issues.push(...page.issues);
    next = page.nextPageToken;
  } while (next);
  return issues;
}

/**
 * Pull every issue assigned to you as User Guideline and group them by epic,
 * because one BookStack page documents one epic plus all of its child issues.
 */
export async function fetchEpicGroups(): Promise<EpicGroup[]> {
  const ctx = await jiraContext();
  try {
    await whoAmI(ctx);
    const allFields = await getJson<JiraField[]>(ctx, '/rest/api/3/field');
    const linkField = await resolveFieldId(allFields, config.jira.guidelineLinkField, 'string');
    const sprintField = await resolveFieldId(allFields, config.jira.sprintField, 'array');
    if (!linkField) {
      const similar = allFields
        .filter((f) => /guideline|link/i.test(f.name))
        .map((f) => `${f.name} (${f.id})`)
        .slice(0, 15);
      throw new Error(
        `Jira field "${config.jira.guidelineLinkField}" not found among ${allFields.length} fields.\n` +
          (similar.length
            ? `  Similar fields:\n    - ${similar.join('\n    - ')}\n  Put the right name or ID in JIRA_GUIDELINE_LINK_FIELD in .env.`
            : '  No similar field is visible to this account. It may lack access to the project.'),
      );
    }

    const fields = ['summary', 'status', 'issuetype', 'parent', linkField, sprintField].filter(
      Boolean,
    ) as string[];
    const raw = await searchAll(ctx, config.jira.jql, fields);

    const toRef = (i: RawIssue): IssueRef => ({
      key: i.key,
      summary: i.fields.summary,
      type: i.fields.issuetype?.name ?? '',
      status: i.fields.status?.name ?? '',
      guidelineLink: i.fields[linkField] || null,
    });

    const groups = new Map<string, EpicGroup>();
    const ensure = (key: string, summary = '', status = '') => {
      if (!groups.has(key)) {
        groups.set(key, {
          key,
          summary,
          status,
          sprints: [],
          url: `${config.jira.baseUrl}/browse/${key}`,
          epic: null,
          children: [],
        });
      }
      return groups.get(key)!;
    };

    for (const i of raw) {
      const isEpic = i.fields.issuetype?.name === 'Epic';
      const parent = i.fields.parent;
      const group = isEpic
        ? ensure(i.key, i.fields.summary, i.fields.status?.name)
        : ensure(parent?.key ?? i.key, parent?.fields?.summary ?? i.fields.summary, parent?.fields?.status?.name);
      if (isEpic) {
        group.epic = toRef(i);
        group.summary = i.fields.summary;
        group.status = i.fields.status?.name ?? group.status;
      } else {
        group.children.push(toRef(i));
      }
      const sprints: Array<{ name: string }> = (sprintField && i.fields[sprintField]) || [];
      for (const s of sprints) if (!group.sprints.includes(s.name)) group.sprints.push(s.name);
    }

    let list = [...groups.values()];
    if (config.sprintFilter) {
      const f = config.sprintFilter.toLowerCase();
      list = list.filter((g) => g.sprints.some((s) => s.toLowerCase().includes(f)));
    }
    return list.sort((a, b) => a.key.localeCompare(b.key, undefined, { numeric: true }));
  } finally {
    await ctx.dispose();
  }
}
