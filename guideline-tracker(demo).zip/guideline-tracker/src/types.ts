export interface IssueRef {
  key: string;
  summary: string;
  type: string;
  status: string;
  guidelineLink: string | null;
}

export interface EpicGroup {
  key: string;
  summary: string;
  status: string;
  sprints: string[];
  url: string;
  epic: IssueRef | null; // null when the epic itself isn't assigned to you
  children: IssueRef[];
}

export interface GuidelinePage {
  name: string;
  url: string;
  book: string;
  /** BookStack page id — lets a /draft/{id} or /link/{id} URL in Jira be matched to the published page. */
  id?: number;
  draft?: boolean;
}

export interface ImageCheck {
  total: number;
  broken: string[];
}
