import fs from 'node:fs';
import { chromium, request } from '@playwright/test';
import { bookstackAuthMode, config, paths } from './config';

/**
 * Opens a real browser on the login page; you log in yourself (tick "Remember me"),
 * and the session is saved to .auth/ — no password is ever stored by this project.
 * The browser closes on its own as soon as the login succeeds.
 */
export async function saveSession(name: string, url: string, file: string, waitForEnter = false) {
  const browser = await chromium.launch({
    headless: false,
    executablePath: process.env.CHROMIUM_PATH || undefined,
  });
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto(url);
  if (waitForEnter) {
    const rl = (await import('node:readline/promises')).createInterface({ input: process.stdin, output: process.stdout });
    await rl.question(`\n→ Log in to ${name} in the opened browser, then press Enter here… `);
    rl.close();
  } else {
    console.log(`\n→ Log in to ${name} in the browser window (tick "Remember me"). It closes by itself when you're in.`);
    await page.waitForURL((u) => !/\/login/.test(u.pathname), { timeout: 5 * 60_000 });
    await page.waitForLoadState('domcontentloaded');
  }
  fs.mkdirSync(paths.authDir, { recursive: true });
  await context.storageState({ path: file });
  await browser.close();
  console.log(`✓ ${name} session saved`);
}

/**
 * Runs before every check. If the saved BookStack session has expired, it asks you to log
 * in again right away instead of letting every test fail. A still-valid session is saved
 * back, so refreshed cookies keep it alive longer.
 */
export async function ensureBookstackSession() {
  if (config.mock || bookstackAuthMode() !== 'session') return;
  const base = config.bookstack.baseUrl;
  if (!base) return; // assertConfig() reports the missing setting
  if (fs.existsSync(paths.bookstackState)) {
    const ctx = await request.newContext({ baseURL: base, storageState: paths.bookstackState });
    try {
      const res = await ctx.get('/search?term=test');
      if (res.ok() && !/\/login/.test(new URL(res.url()).pathname)) {
        await ctx.storageState({ path: paths.bookstackState });
        console.log('BookStack: session OK');
        return;
      }
    } finally {
      await ctx.dispose();
    }
    console.log('BookStack: session expired');
  } else {
    console.log('BookStack: no saved session yet');
  }
  await saveSession('BookStack', `${base}/login`, paths.bookstackState);
}
