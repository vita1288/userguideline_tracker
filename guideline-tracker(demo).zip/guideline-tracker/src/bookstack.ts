import { request, type APIRequestContext, type Page } from '@playwright/test';
import { config, bookstackAuthMode } from './config';
import type { GuidelinePage, ImageCheck } from './types';

/** "CNX-1908" must not match a page called "CNX-19086 …". */
const titleMatches = (name: string, key: string) =>
  new RegExp(`^\\s*\\[?${key}(?![0-9])`, 'i').test(name);

export async function bookstackApi(): Promise<APIRequestContext> {
  const { baseUrl, tokenId, tokenSecret } = config.bookstack;
  return request.newContext({
    baseURL: baseUrl,
    extraHTTPHeaders: { Authorization: `Token ${tokenId}:${tokenSecret}`, Accept: 'application/json' },
  });
}

/** Find the published guideline page for an epic key. Returns every match (duplicates are reported too). */
export async function findGuidelinePages(
  key: string,
  opts: { api?: APIRequestContext; page?: Page },
): Promise<GuidelinePage[]> {
  if (bookstackAuthMode() === 'token' && opts.api) {
    const params = new URLSearchParams({ query: `${key} {type:page}`, count: '50' });
    const res = await opts.api.get(`/api/search?${params}`);
    if (!res.ok()) throw new Error(`BookStack API ${res.status()} — check BOOKSTACK_TOKEN_ID/SECRET`);
    const body = (await res.json()) as {
      data: Array<{ id: number; name: string; url: string; book?: { name: string } }>;
    };
    return body.data
      .filter((r) => titleMatches(r.name, key))
      .map((r) => ({ id: r.id, name: r.name, url: r.url, book: r.book?.name ?? bookFromUrl(r.url) }));
  }

  if (!opts.page) throw new Error('BookStack session mode needs a browser page');
  const page = opts.page;
  await page.goto(`${config.bookstack.baseUrl}/search?term=${encodeURIComponent(`${key} {type:page}`)}`);
  if (/\/login/.test(page.url())) {
    throw new Error('BookStack session expired — run `npm run login bookstack` again');
  }
  const results = await page.$$eval('a[href*="/page/"]', (links) =>
    links.map((a) => {
      // The title element differs between BookStack versions; fall back to the first text line.
      const named = a.querySelector('.entity-list-item-name, h4');
      const text = (named?.textContent ?? (a as HTMLElement).innerText ?? '').trim();
      return {
        name: text.split('\n').map((l) => l.trim()).find(Boolean) ?? '',
        url: (a as HTMLAnchorElement).href,
        id: Number((a as HTMLElement).dataset.entityId) || undefined,
      };
    }),
  );
  const seen = new Set<string>();
  return results
    .filter((r) => titleMatches(r.name, key) && !seen.has(r.url) && seen.add(r.url))
    .map((r) => ({ ...r, book: bookFromUrl(r.url) }));
}

export function bookFromUrl(url: string) {
  const m = url.match(/\/books\/([^/]+)/);
  return m ? m[1].replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()) : '';
}

/** What a link in Jira points at: a page by slug, or a page id (draft or permalink URL). */
export function parseLink(url: string): { book?: string; slug?: string; id?: number; draft?: boolean } {
  const u = url.trim().toLowerCase();
  let m = u.match(/\/books\/([^/?#]+)\/page\/([^/?#]+)/);
  if (m) return { book: m[1], slug: m[2] };
  m = u.match(/\/books\/[^/?#]+\/draft\/(\d+)/);
  if (m) return { id: Number(m[1]), draft: true };
  m = u.match(/\/link\/(\d+)/);
  if (m) return { id: Number(m[1]) };
  return {};
}

export type LinkCheck = 'ok' | 'draft-url' | 'wrong' | 'unverifiable';

/**
 * Does the Jira link point at the found page? Compared by page id when the link is a
 * draft or permalink URL (/draft/812, /link/812), otherwise by book + page slug.
 */
export function checkLink(link: string, page: GuidelinePage): LinkCheck {
  const t = parseLink(link);
  if (t.slug) {
    const p = parseLink(page.url);
    return t.slug === p.slug && t.book === p.book ? 'ok' : 'wrong';
  }
  if (t.id) {
    if (!page.id) return 'unverifiable';
    if (t.id !== page.id) return 'wrong';
    return t.draft ? 'draft-url' : 'ok';
  }
  return 'wrong';
}

/** Kept for compatibility: true when two page URLs point at the same page. */
export function samePage(a: string, b: string) {
  return checkLink(a, { name: '', url: b, book: '' }) === 'ok';
}

/**
 * Open the page like a reader would and confirm every image is actually served.
 * Each image URL is requested over HTTP with the reader's session, so lazy-loaded
 * images below the fold are not mistaken for broken ones.
 */
export async function checkImages(page: Page, url: string): Promise<ImageCheck> {
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  if (/\/login/.test(page.url())) {
    throw new Error('BookStack session expired — run `npm run login bookstack` again');
  }
  const srcs = await page.$$eval('.page-content img', (imgs) =>
    [...new Set((imgs as HTMLImageElement[]).map((i) => i.currentSrc || i.src).filter(Boolean))],
  );
  const broken: string[] = [];
  for (const src of srcs) {
    if (src.startsWith('data:')) continue;
    try {
      const res = await page.request.get(src, { timeout: 20_000 });
      const type = res.headers()['content-type'] ?? '';
      if (!res.ok() || !type.startsWith('image/')) broken.push(src);
    } catch {
      broken.push(src);
    }
  }
  return { total: srcs.length, broken };
}

/**
 * Image check without a browser session (API-token mode): read the page HTML through the
 * API and request every image URL. Gallery images are normally public files, so no login
 * is needed; if the site serves them only to logged-in users, a clear error says so.
 */
export async function checkImagesViaApi(api: APIRequestContext, pageId: number): Promise<ImageCheck> {
  const res = await api.get(`/api/pages/${pageId}`);
  if (!res.ok()) throw new Error(`BookStack API ${res.status()} while reading page ${pageId}`);
  const { html } = (await res.json()) as { html: string };
  const srcs = [...new Set([...html.matchAll(/<img[^>]+src="([^"]+)"/gi)].map((m) => m[1]))].filter(
    (s) => !s.startsWith('data:'),
  );
  const plain = await request.newContext({ baseURL: config.bookstack.baseUrl });
  const broken: string[] = [];
  let loginWalls = 0;
  try {
    for (const src of srcs) {
      try {
        const r = await plain.get(src, { timeout: 20_000 });
        const type = r.headers()['content-type'] ?? '';
        if (/\/login/.test(r.url())) loginWalls++;
        if (!r.ok() || !type.startsWith('image/')) broken.push(src);
      } catch {
        broken.push(src);
      }
    }
  } finally {
    await plain.dispose();
  }
  if (srcs.length && loginWalls === srcs.length) {
    throw new Error('Images need a login on this BookStack — run `npm run login bookstack` or set CHECK_IMAGES=false');
  }
  return { total: srcs.length, broken };
}

export type ResolvedLink =
  | { state: 'published'; page: GuidelinePage }
  | { state: 'draft' }
  | { state: 'broken'; reason: string };

/**
 * Open the "User Guideline Link" from Jira exactly like a reader would and see what it
 * really is: a published page, a page that is still a draft, or a broken link.
 */
export async function resolveLink(link: string, page: Page): Promise<ResolvedLink> {
  const res = await page.goto(link, { waitUntil: 'domcontentloaded' });
  const finalUrl = page.url();
  if (/\/login/.test(new URL(finalUrl).pathname)) {
    throw new Error('BookStack session expired — run `npm run login bookstack` again');
  }
  if (res && res.status() >= 400) return { state: 'broken', reason: `link returns HTTP ${res.status()}` };
  if (/\/draft\/\d+/.test(finalUrl)) return { state: 'draft' };
  if (!/\/page\//.test(finalUrl)) return { state: 'broken', reason: `link does not open a page (${finalUrl})` };
  const info = await page.evaluate(() => {
    const h1 = document.querySelector('.page-content h1, main h1, h1');
    const display = document.querySelector('[page-display]')?.getAttribute('page-display');
    return { title: h1?.textContent?.trim() ?? document.title, id: Number(display) || undefined };
  });
  const fromLink = parseLink(link).id;
  return {
    state: 'published',
    page: { name: info.title, url: finalUrl.split('#')[0], id: info.id ?? fromLink, book: bookFromUrl(finalUrl) },
  };
}

/** True when a page title belongs to the epic key ("CNX-19086 …" for CNX-19086). */
export const titleIsFor = (title: string, key: string) => titleMatches(title, key);
