import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(__dirname, '..');

const bool = (v: string | undefined, def: boolean) =>
  v === undefined || v === '' ? def : /^(1|true|yes)$/i.test(v);

const trimSlash = (u: string) => u.replace(/\/+$/, '');

export const paths = {
  root,
  authDir: path.join(root, '.auth'),
  jiraState: path.join(root, '.auth', 'jira.json'),
  bookstackState: path.join(root, '.auth', 'bookstack.json'),
  cacheFile: path.join(root, '.cache', 'epics.json'),
  reportsDir: path.join(root, 'reports'),
  mockFile: path.join(root, 'mock', 'epics.json'),
};

export const config = {
  mock: bool(process.env.MOCK, false),

  jira: {
    baseUrl: trimSlash(process.env.JIRA_BASE_URL ?? ''),
    email: process.env.JIRA_EMAIL ?? '',
    apiToken: process.env.JIRA_API_TOKEN ?? '',
    jql: process.env.JIRA_JQL || '"User Guideline" = currentUser() ORDER BY created DESC',
    guidelineLinkField: process.env.JIRA_GUIDELINE_LINK_FIELD || 'User Guideline Link',
    sprintField: process.env.JIRA_SPRINT_FIELD || 'Sprint',
  },

  bookstack: {
    baseUrl: trimSlash(process.env.BOOKSTACK_URL ?? ''),
    tokenId: process.env.BOOKSTACK_TOKEN_ID ?? '',
    tokenSecret: process.env.BOOKSTACK_TOKEN_SECRET ?? '',
  },

  sprintFilter: process.env.SPRINT_FILTER ?? '',
  checkImages: bool(process.env.CHECK_IMAGES, true),
  /** true: a child issue without the link fails the check. false (default): it is only a warning. */
  requireChildLinks: bool(process.env.REQUIRE_CHILD_LINKS, false),
  /** true: epics without a published page fail the run. false (default): they are reported as "not published yet". */
  strict: bool(process.env.STRICT, false),
  /** Save a screenshot of each guideline page (needs the browser session). */
  screenshots: bool(process.env.SCREENSHOTS, true),
  /** true: capture the whole page top to bottom. false (default): the first screen only. */
  fullPageScreenshots: bool(process.env.FULL_PAGE_SCREENSHOTS, false),
};

export const jiraAuthMode = (): 'token' | 'session' =>
  config.jira.email && config.jira.apiToken ? 'token' : 'session';

export const bookstackAuthMode = (): 'token' | 'session' =>
  config.bookstack.tokenId && config.bookstack.tokenSecret ? 'token' : 'session';

export const hasSession = (file: string) => fs.existsSync(file);

/** Fail early with a readable message instead of a cryptic network error. */
export function assertConfig() {
  if (config.mock) return;
  const missing: string[] = [];
  if (!config.jira.baseUrl) missing.push('JIRA_BASE_URL');
  if (!config.bookstack.baseUrl) missing.push('BOOKSTACK_URL');
  if (jiraAuthMode() === 'session' && !hasSession(paths.jiraState))
    missing.push('JIRA_EMAIL + JIRA_API_TOKEN (or run `npm run login`)');
  if (bookstackAuthMode() === 'session' && !hasSession(paths.bookstackState))
    missing.push('BOOKSTACK_TOKEN_ID + BOOKSTACK_TOKEN_SECRET (or run `npm run login`)');
  if (missing.length) {
    throw new Error(
      `Missing configuration:\n  - ${missing.join('\n  - ')}\nCopy .env.example to .env and fill it in.`,
    );
  }
}
