import { defineConfig } from '@playwright/test';
import { config, hasSession, paths } from './src/config';

export default defineConfig({
  testDir: './tests',
  timeout: 90_000,
  fullyParallel: true,
  workers: 4,
  retries: process.env.CI ? 1 : 0, // a missing guideline is deterministic; retry only on CI for network blips
  reporter: [
    ['list'],
    ['html', { outputFolder: 'reports/html', open: 'never' }],
    ['./reporters/summary-reporter.ts', { outputDir: 'reports' }],
  ],
  use: {
    baseURL: config.bookstack.baseUrl || undefined,
    storageState: !config.mock && hasSession(paths.bookstackState) ? paths.bookstackState : undefined,
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
  },
});
